package com.example.tracker;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;

import java.util.LinkedList;

public class DashboardActivity extends AppCompatActivity {
    RecyclerView cRecyclerView;
    private CategoryListAdapter cAdapter;
    public static LinkedList<String> categoryList = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        FloatingActionButton categoryFAB = findViewById(R.id.category_fab);
        categoryFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int categoryLastSize = categoryList.size();
                categoryList.add(new String());
                // Notify the adapter, that the data has changed.
                cRecyclerView.getAdapter().notifyItemInserted(categoryLastSize);
                // Scroll to the bottom.
                cRecyclerView.smoothScrollToPosition(categoryLastSize);
            }
        });

        // Get a handle to the RecyclerView.
        cRecyclerView = findViewById(R.id.category_recycler_view);
        // Create an adapter and supply the data to be displayed.
        cAdapter = new CategoryListAdapter(this,categoryList);
        // Connect the adapter with the RecyclerView.
        cRecyclerView.setAdapter(cAdapter);
        // Give the RecyclerView a default layout manager.
        cRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
    }
}

